# spring-boot2-oauth2-auth-server-jwt-mysql

Hello Everyone,

Here is the video of Spring Boot 2.0 Authorization Server | OAuth2 | JWT and MySQL

https://youtu.be/wxebTn_a930

Please subscribe my YouTube channel - https://www.youtube.com/c/Talk2Amareswaran

Please like my Facebook page - https://www.facebook.com/talk2amareswaran/

Please join Facebook group - https://www.facebook.com/groups/271796230307847/
